// transpile:main

import { AndroidUiautomator2Driver } from './lib/driver';

export { AndroidUiautomator2Driver };
export default AndroidUiautomator2Driver;
